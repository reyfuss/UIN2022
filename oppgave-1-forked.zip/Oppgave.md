Oppgaven er å finne det lengste ordet i en statisk tekst.

I denne oppgaven får du øvd på:

- bruk av for-løkke (eller forEach)
- bruk av array
- bruk av conditionals (if / else)
