Oppgaven er å skrive ut en liste med brukere som vi kan bruke til å søke etter navn eller filtrere på alder.

I denne oppgaven får du øvd på:

- å hente ut HTML #id-er
- bruke template literals ``til å lage HTML
- bruk av for-of (eller vanlig for-løkke)
- oppdatere grensesnittet basert på endringer i lister
- lytte til ulike eventer (click og keyup)
- bruke ulike array metoder (.find og .filter) for å søke i en liste
- bruk av objekter
- lage og kombinere funksjoner
